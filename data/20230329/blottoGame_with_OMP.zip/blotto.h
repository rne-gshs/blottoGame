#ifndef _BLOTTO_H_
#define _BLOTTO_H_

#include <vector>

namespace blt
{
	void gen(int, int, std::vector<int>&);
	int game(std::vector<int>, std::vector<int>);
} // blt

#endif //_BLOTTO_H_
