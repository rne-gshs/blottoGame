#include "blotto.h"

#include <iostream>
#include <vector>
#include <array>
#include <memory.h>
#include <random>

std::random_device rd;
std::mt19937 mtgen(rd());

namespace blt
{
	void gen(int n, int k, std::vector<int> &b) // 1000
	{
		b.resize(n);
		std::vector<char> v(n+k-1, 0);
		std::fill(v.begin(), v.begin() + k, 1);
		std::shuffle(v.begin(), v.end(), mtgen);

		int cnt = 0, idx = 0;
		for(char &i:v)
		{
			if(i)
				cnt++;
			else
			{
				b[idx++] = cnt;
				cnt = 0;
			}
		}
		b[n-1] = cnt;
	}

	int game(std::vector<int> a, std::vector<int> b) // 2000
	{
		int sz = a.size();
		if(sz != b.size())
		{
			std::cerr << "blt::game" << std::endl;
			std::cerr << "wrong array size " << a.size() << " " << b.size() << std::endl;
			exit(2000);
		}

		std::array<int, 2> w;
		w.fill(0);
		for(int i = 0; i < sz; i++)
		{
			int t = a[i] - b[i];
			if(t > 0)
				w[0]++;
			else if(t < 0)
				w[1]++;
		}

		if(w[0] > w[1])
			return 1;
		else if(w[0] == w[1])
			return 0;
		else
			return -1;
	}

} // blt