#include <iostream>
#include <vector>
#include <memory.h>
#include "blotto.h"

struct st
{
	std::vector<int> v;
	int w;

	bool operator<(st &a)
	{
		return w > a.w;
	}
};

std::vector<st> buff;

void f(int s, std::vector<int> &t)
{
	if(t.size() == 4)
	{
		t.push_back(s);
		/*for(int &i:t)
			std::cout << i << " ";
		std::cout << std::endl;*/

		std::vector<int> k;
		int S = 0;
		for(int i = 0; i < 10000; i++)
		{
			blt::gen(5, 20, k);
			S += blt::game(t, k);
		}

		buff.push_back({t, S});

		/*for(int i = 0; i < 5; i++)
			std::cout << t[i] << " ";
		std::cout << S << std::endl;*/
		std::cerr << S << " ";

		t.pop_back();
		return;
	}

	for(int i = s; i >= 0; i--)
	{
		t.push_back(i);
		f(s - i, t);
		t.pop_back();
	}
}

int main()
{
	/*std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);
    std::cout.tie(NULL);*/

	std::vector<int> t;
	f(20, t);

	std::cerr << "sorting";

	std::sort(buff.begin(), buff.end());
	for(auto &i:buff)
	{
		for(int j=0; j<5; j++)
			std::cout << i.v[j] << " ";
		std::cout << i.w << std::endl;
	}

	return 0;
}